
package com.grendkuk.toppinggps;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.util.*;

public class MainActivity extends Activity {
    private LocationManager locationManager;
    private GpsView gpsView;
    private TextView status, accuracy, speed, area, distance, guide;
    private EditText widthInput, fieldInput;
    private Location lastLoc, origin;
    private double totalMetres = 0, areaM2 = 0, abBearing = Double.NaN, lastMoveBearing = Double.NaN;
    private final ArrayList<Location> points = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,18);
        root.setBackgroundColor(Color.rgb(16,20,24));

        TextView title = tv("Topping GPS Coverage Map", 24, true);
        root.addView(title);

        widthInput = input("1.85");
        fieldInput = input("");
        root.addView(label("Mower width metres"));
        root.addView(widthInput);
        root.addView(label("Field acres optional"));
        root.addView(fieldInput);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button start = btn("Start GPS");
        Button reset = btn("Reset");
        Button clear = btn("Clear");
        buttons.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(reset, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(clear, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(buttons);

        gpsView = new GpsView(this);
        root.addView(gpsView, new LinearLayout.LayoutParams(-1, 0, 1));

        status = tv("Status: Off", 18, true);
        accuracy = tv("Accuracy: -- m", 18, false);
        speed = tv("Speed: -- km/h", 18, false);
        area = tv("Area: 0.00 ac", 18, false);
        distance = tv("Distance: 0 m", 18, false);
        guide = tv("Guide: start driving first pass", 18, true);

        root.addView(status); root.addView(accuracy); root.addView(speed);
        root.addView(area); root.addView(distance); root.addView(guide);
        setContentView(root);

        start.setOnClickListener(v -> startGps());
        reset.setOnClickListener(v -> resetAll());
        clear.setOnClickListener(v -> { points.clear(); areaM2=0; totalMetres=0; gpsView.invalidate(); updateStats(null, 0); });
    }

    private TextView tv(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.WHITE); t.setPadding(0,8,0,8);
        if(bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
    private TextView label(String s) {
        TextView t = tv(s, 14, false);
        t.setTextColor(Color.rgb(210,220,230));
        return t;
    }
    private EditText input(String s) {
        EditText e = new EditText(this);
        e.setText(s);
        e.setTextSize(18);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setSingleLine(true);
        e.setTextColor(Color.BLACK);
        e.setBackgroundColor(Color.WHITE);
        return e;
    }
    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        return b;
    }

    private double mowerWidth() {
        try { return Math.max(0.5, Double.parseDouble(widthInput.getText().toString())); }
        catch(Exception e) { return 1.85; }
    }

    private void startGps() {
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
            return;
        }
        status.setText("Status: GPS starting");
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0.3f, listener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0.3f, listener);
        } catch(SecurityException e) {
            status.setText("Status: permission error");
        }
    }

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) {
            if(origin == null) origin = loc;
            float sp = loc.hasSpeed() ? loc.getSpeed()*3.6f : 0;

            if(lastLoc != null) {
                double d = lastLoc.distanceTo(loc);
                if(d > 0.35 && d < 80) {
                    totalMetres += d;
                    areaM2 += d * mowerWidth();
                    if(d > 2) {
                        lastMoveBearing = lastLoc.bearingTo(loc);
                        if(Double.isNaN(abBearing)) abBearing = lastMoveBearing;
                    }
                    points.add(loc);
                }
            } else {
                points.add(loc);
            }
            lastLoc = loc;
            updateStats(loc, sp);
            gpsView.invalidate();
        }
    };

    private void updateStats(Location loc, float sp) {
        status.setText("Status: On");
        if(loc != null) accuracy.setText("Accuracy: " + Math.round(loc.getAccuracy()) + " m");
        speed.setText(String.format(Locale.US, "Speed: %.1f km/h", sp));
        double acres = areaM2 / 4046.8564224;
        area.setText(String.format(Locale.US, "Area: %.2f ac", acres));
        distance.setText("Distance: " + Math.round(totalMetres) + " m");
        if(loc != null && origin != null && !Double.isNaN(abBearing)) {
            double off = wrappedOffset(signedOffset(loc), mowerWidth());
            if(Math.abs(off) < mowerWidth()*0.25) guide.setText(String.format(Locale.US, "Guide: on line %.1f m", off));
            else if(off > 0) guide.setText(String.format(Locale.US, "Guide: move LEFT %.1f m", Math.abs(off)));
            else guide.setText(String.format(Locale.US, "Guide: move RIGHT %.1f m", Math.abs(off)));
        }
    }

    private void resetAll() {
        origin = lastLoc;
        abBearing = lastMoveBearing;
        totalMetres = 0; areaM2 = 0;
        points.clear();
        if(lastLoc != null) points.add(lastLoc);
        gpsView.invalidate();
    }

    private PointF project(Location l) {
        if(origin == null) return new PointF(0,0);
        double R = 6371000;
        double x = Math.toRadians(l.getLongitude() - origin.getLongitude()) * R * Math.cos(Math.toRadians(origin.getLatitude()));
        double y = Math.toRadians(l.getLatitude() - origin.getLatitude()) * R;
        return new PointF((float)x, (float)y);
    }

    private double signedOffset(Location loc) {
        PointF p = project(loc);
        double th = Math.toRadians(abBearing);
        double dx = Math.sin(th), dy = Math.cos(th);
        return p.x * dy - p.y * dx;
    }

    private double wrappedOffset(double off, double width) {
        double r = off % width;
        if(r > width/2) r -= width;
        if(r < -width/2) r += width;
        return r;
    }

    public class GpsView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float scale = 4f;
        public GpsView(Context c) { super(c); }

        @Override protected void onDraw(Canvas c) {
            c.drawColor(Color.rgb(39,49,59));
            float cx = getWidth()/2f, cy = getHeight()/2f;
            double width = mowerWidth();

            if(origin != null && !Double.isNaN(abBearing)) {
                p.setColor(Color.argb(90,255,255,255));
                p.setStrokeWidth(2);
                double th = Math.toRadians(abBearing);
                double dx = Math.sin(th), dy = Math.cos(th);
                double px = dy, py = -dx;
                for(int i=-80;i<=80;i++) {
                    double off = i*width;
                    float x1 = cx + (float)((px*off - dx*300)*scale);
                    float y1 = cy - (float)((py*off - dy*300)*scale);
                    float x2 = cx + (float)((px*off + dx*300)*scale);
                    float y2 = cy - (float)((py*off + dy*300)*scale);
                    c.drawLine(x1,y1,x2,y2,p);
                }
            }

            if(points.size() > 1) {
                p.setColor(Color.argb(190,125,255,155));
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
                p.setStrokeWidth(Math.max(8f, (float)(width*scale)));
                Path path = new Path();
                for(int i=0;i<points.size();i++) {
                    PointF q = project(points.get(i));
                    float x = cx + q.x*scale, y = cy - q.y*scale;
                    if(i==0) path.moveTo(x,y); else path.lineTo(x,y);
                }
                c.drawPath(path,p);
            }

            if(lastLoc != null) {
                PointF q = project(lastLoc);
                p.setColor(Color.rgb(47,140,255));
                c.drawCircle(cx + q.x*scale, cy - q.y*scale, 14, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(4);
                p.setColor(Color.WHITE);
                c.drawCircle(cx + q.x*scale, cy - q.y*scale, 14, p);
                p.setStyle(Paint.Style.FILL);
            }
        }
    }
}
