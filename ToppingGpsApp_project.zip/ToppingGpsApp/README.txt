# Topping GPS Android App

This is a simple native Android project for testing phone GPS while topping.

## Build APK
1. Install Android Studio.
2. Open this folder: ToppingGpsApp
3. Let Android Studio sync Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. Copy the APK to your phone and install it.

The app asks for location permission and paints a rough green coverage path.
Phone GPS is not precision guidance; expect several metres error.
